package com.jobcho.alarm;

public interface WorkspaceAlarmCount {
	Integer getWorkspaceId();
	Integer getCnt();
}
